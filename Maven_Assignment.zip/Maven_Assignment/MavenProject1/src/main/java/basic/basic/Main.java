package basic.basic;

import basic.implementation.BasicImplementation;
import basic.interfaces.BasicInterface;

public class Main {
	public static void main(String[] args) {
	}
}