package basic.implementation;

import basic.interfaces.BasicInterface;

public class BasicImplementation implements BasicInterface {
	public void execute(int a, int b){
		int add=a+b;
		int sub=(a>b)?(a-b):(b-a);
		int mul=a*b;
		int div=(a>b)?(a/b):(b/a);
		System.out.println("Added result: " + add);
		System.out.println("Subtracted result: " + sub);
		System.out.println("Multiplied result: " + mul);
		System.out.println("Divided result: " + div);
	}
}
