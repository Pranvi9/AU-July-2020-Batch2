package basic.interfaces;

public interface BasicInterface {
	public void execute(int a , int b);
}
