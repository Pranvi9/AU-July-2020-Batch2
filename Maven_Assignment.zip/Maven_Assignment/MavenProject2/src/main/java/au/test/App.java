package au.test;

import java.util.Scanner;

import basic.implementation.BasicImplementation;
import basic.interfaces.BasicInterface;

public class App {

	public static void main(String[] args) {
		System.out.println("Enter numbers to perform operations");
		Scanner input = new Scanner(System.in);
		int a=input.nextInt();
		int b=input.nextInt();
		BasicInterface connector = new BasicImplementation();
		connector.execute(a,b);
	}

}
