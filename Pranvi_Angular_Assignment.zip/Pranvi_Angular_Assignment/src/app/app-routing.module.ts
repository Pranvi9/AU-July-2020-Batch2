import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Page1Component } from "./assignment/page1/page1.component";
import { Page3Component } from "./assignment/page3/page3.component";
const routes: Routes = [
  {path: 'page1', component: Page1Component},
  {path: 'page3', component: Page3Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
