// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent {
//   // myName = "Pranvi"

//   // today=new Date();

//   // userFormGroup = new FormGroup ({
//   //   username: new FormControl(""),
//   //   userphone: new FormControl(""),
//   //   userage: new FormControl(""),
//   //   usergender: new FormControl(""),
//   // });

// // users=[]
// //   constructor(private httpClient: HttpClient) {
// //     this.httpClient
// //       .get("http://demo5214125.mockable.io/get")
// //       .subscribe((data: any) => (this.users=data.users));
// //   }

//   // updateName(name) {
//   //   this.myName=name;
//   // }


//   // submitData() {
//   //   // if(this.userFormGroup.valid){}
//   //   // console.log(this.userFormGroup.value);
//   //   alert("submitted");
//   //   // this.userForm.value();
//   // }

// }




import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
}