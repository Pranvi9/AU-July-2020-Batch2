import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyFirstComponent } from './components/my-first/my-first.component';
import { MyDetailsComponent } from './components/my-details/my-details.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { App1Component } from './app1/app1.component';
import { Child1Component } from './child1/child1.component';
import { MultiplyPipe } from './pipes/multiply.pipe';
import { AssignmentComponent } from './assignment/assignment.component';
import { Page1Component } from './assignment/page1/page1.component';
import { Page2Component } from './assignment/page2/page2.component';
import { Page3Component } from './assignment/page3/page3.component';

@NgModule({
  declarations: [
    AppComponent,
    MyFirstComponent,
    MyDetailsComponent,
    App1Component,
    Child1Component,
    MultiplyPipe,
    AssignmentComponent,
    Page1Component,
    Page2Component,
    Page3Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
