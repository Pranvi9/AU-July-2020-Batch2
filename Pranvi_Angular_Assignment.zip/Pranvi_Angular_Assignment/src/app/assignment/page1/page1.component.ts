import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component {

  rForm: FormGroup;
  post:any;
  parentpost:any[]=[];
  address:string = '';
  name:string = '';
  lname:string = '';
  idNo:number = 0;
  titleAlert:string = 'This field is required';

  constructor(private fb: FormBuilder) {

    this.rForm = fb.group({
      'name': [null, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(20)])],
      'lname': [null, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(20)])],
      'idNo': [null, Validators.required],
      'address': [null, Validators.compose([Validators.required, Validators.minLength(10), Validators.maxLength(50)])],
      'validate' : ''
    });

  }

  addPost(post) {
    this.address = post.address;
    this.name = post.name;
    this.lname = post.lname;
    this.idNo = post.idNo
    this.parentpost.push(post);
  }
}
